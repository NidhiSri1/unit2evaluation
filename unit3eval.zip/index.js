function disp() {
  window.location.href = "menu.html";
}
